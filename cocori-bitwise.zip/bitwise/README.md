1 File is bitwise-funzies.c
  Binary file is ./bitwise.
  Result is in first.txt.

2 File is bitwise-sizeof.c
  Binary file is ./bitwisesizeof 
  Result is in second.txt

The mean of "sizeof" function is how many byte each data(int, double, long, ...)is.

3 File is 64bitwise.c
  Binary file is ./64bitwise
  Result is in third.txt

We have to use long to declare 64bit integers.

4 Minimum value of 
These are the list of minimum and maximum value of each int.

Minimum value of short int = -32768
Maximum value of short int = 32767
Maximum value of short int = 65535

Maximum value of int = -2147483648
Minimum value of int = 2147483647
Maximum value of int = 4294967295

Maximum value of long int = -9223372036854775808
Maximum value of long int = 9223372036854775807
Maximum value of long int = 18446744073709551615
