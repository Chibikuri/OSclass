# Addressing and Memory Segments
## First
source → memory1.c 
binary → memory1

## Second
source → memory2.c
binary → memory2

In my system, the stack goes up.

## Third
source → memory3.c
binary → memory3

## Fourth 
source → memory4.c
binary → memory4

## Fifth
source → memroy5.c
binary → memory5

## Sixth
file → memory6.txt
